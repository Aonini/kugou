import React, { Component } from 'react'

export default class Singer extends Component {
  componentDidMount() {

  }
  render() {
    return (
      <div>
        Singer
      </div>
    )
  }
}
